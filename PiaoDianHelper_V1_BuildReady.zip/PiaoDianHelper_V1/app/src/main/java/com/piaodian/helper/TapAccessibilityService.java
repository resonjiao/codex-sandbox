package com.piaodian.helper;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Manual, opt-in local tap assistance. Strict foreground package check; finite gesture budget;
 * hard stop on payment or verification text; no network, credentials, CAPTCHA, or checkout.
 */
public class TapAccessibilityService extends AccessibilityService {
    private static TapAccessibilityService instance;
    private static final int NAVY = Color.rgb(15, 23, 42);
    private static final int BLUE = Color.rgb(37, 99, 235);
    private static final String[] STOP_MARKERS = {
        "验证码", "安全验证", "人机验证", "滑动验证", "图形验证", "短信验证",
        "提交订单", "确认订单", "去支付", "立即支付", "确认支付", "订单提交成功"
    };
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<Point> points = new ArrayList<>();
    private final ArrayList<Point> draftPoints = new ArrayList<>();
    private WindowManager wm;
    private LinearLayout panel;
    private TextView panelStatus;
    private WindowManager.LayoutParams panelParams;
    private FrameLayout captureView;
    private TextView captureHint;
    private Runnable scheduledStart;
    private long finishTime;
    private boolean running;
    private boolean armed;
    private int tapIndex;
    private int interval;
    private int maxCount;
    private int generation;
    private float initialX, initialY;
    private int initialPanelX, initialPanelY;

    public static TapAccessibilityService getInstance() { return instance; }
    private int d(float dp) { return Math.round(dp * getResources().getDisplayMetrics().density); }
    private GradientDrawable bg(int color, int r) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(d(r));
        return drawable;
    }
    private TextView label(String s, int size, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }
    private Button mini(String title, int color) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(title);
        b.setTextSize(12);
        b.setTextColor(Color.WHITE);
        b.setPadding(0, 0, 0, 0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setBackground(bg(color, 8));
        return b;
    }
    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        // We do not collect accessibility event content or upload anything.
        // Every dispatched gesture independently verifies the foreground package and visible text.
    }
    @Override public void onInterrupt() {
        stopActive("无障碍服务中断，已停止");
    }
    @Override public boolean onUnbind(android.content.Intent intent) {
        cleanup();
        return super.onUnbind(intent);
    }
    @Override public void onDestroy() {
        cleanup();
        super.onDestroy();
    }
    private void cleanup() {
        stopActive("已停止");
        closeCapture();
        removePanel();
        instance = null;
    }
    private WindowManager.LayoutParams overlayParams(int w, int h) {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        return p;
    }
    private LinearLayout.LayoutParams childParams(int w, int h) {
        return new LinearLayout.LayoutParams(w == -1 ? -1 : d(w), h == -1 ? -1 : d(h));
    }
    public void showFloatingPanel() {
        if (wm == null) return;
        if (captureView != null) closeCapture();
        if (panel != null) return;
        points.clear();
        points.addAll(TapSettings.loadPoints(this));

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(d(10), d(9), d(10), d(9));
        panel.setBackground(bg(Color.argb(241, 15, 23, 42), 13));
        TextView header = label("≡ 票点助手 · 拖动此处", 13, true, Color.WHITE);
        header.setPadding(d(4), d(1), d(4), d(6));
        panel.addView(header, childParams(-1, 28));
        header.setOnTouchListener((v, e) -> {
            if (panelParams == null || panel == null) return false;
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                initialX = e.getRawX();
                initialY = e.getRawY();
                initialPanelX = panelParams.x;
                initialPanelY = panelParams.y;
                return true;
            }
            if (e.getActionMasked() == MotionEvent.ACTION_MOVE) {
                panelParams.x = Math.max(0, initialPanelX + Math.round(e.getRawX() - initialX));
                panelParams.y = Math.max(0, initialPanelY + Math.round(e.getRawY() - initialY));
                try { wm.updateViewLayout(panel, panelParams); } catch (IllegalArgumentException ignored) {}
                return true;
            }
            return e.getActionMasked() == MotionEvent.ACTION_UP;
        });
        panelStatus = label("当前点位：" + points.size() + "，等待操作", 12, false, Color.rgb(203, 213, 225));
        panelStatus.setPadding(d(4), 0, d(4), d(7));
        panel.addView(panelStatus, childParams(-1, 28));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        panel.addView(row, childParams(-1, 36));

        Button select = mini("取点", BLUE);
        Button start = mini("开始", Color.rgb(22, 163, 74));
        Button stop = mini("停止", Color.rgb(220, 38, 38));
        Button close = mini("关闭", Color.rgb(71, 85, 105));
        Button[] buttons = { select, start, stop, close };
        for (int i = 0; i < buttons.length; i++) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(d(53), d(36));
            if (i != buttons.length - 1) p.rightMargin = d(4);
            row.addView(buttons[i], p);
        }
        select.setOnClickListener(v -> beginCapture());
        start.setOnClickListener(v -> armStart());
        stop.setOnClickListener(v -> stopActive("已由用户停止"));
        close.setOnClickListener(v -> { stopActive("已停止"); removePanel(); });

        panelParams = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT);
        panelParams.x = d(12);
        panelParams.y = d(130);
        try {
            wm.addView(panel, panelParams);
        } catch (RuntimeException ex) {
            panel = null;
            panelStatus = null;
            panelParams = null;
            toast("无法显示悬浮窗，请检查无障碍服务是否开启");
        }
    }
    private void updateStatus(String message) {
        if (panelStatus != null) panelStatus.setText(message);
    }
    private void removePanel() {
        if (panel != null && wm != null) {
            try { wm.removeView(panel); } catch (RuntimeException ignored) { }
        }
        panel = null;
        panelStatus = null;
        panelParams = null;
    }
    private void closeCapture() {
        if (captureView != null && wm != null) {
            try { wm.removeView(captureView); } catch (RuntimeException ignored) { }
        }
        captureView = null;
        captureHint = null;
        draftPoints.clear();
    }
    private void beginCapture() {
        stopActive("点位选择模式");
        removePanel();
        draftPoints.clear();
        captureView = new FrameLayout(this);
        captureView.setBackgroundColor(Color.argb(52, 37, 99, 235));
        captureView.setOnTouchListener((v, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                if (draftPoints.size() >= TapSettings.MAX_POINTS) {
                    toast("最多只允许选择 3 个点，先点‘完成’或‘撤销’");
                    return true;
                }
                int x = Math.round(event.getRawX());
                int y = Math.round(event.getRawY());
                draftPoints.add(new Point(x, y));
                showMarker(event.getX(), event.getY(), draftPoints.size());
                updateCaptureHint();
                return true;
            }
            return true;
        });

        LinearLayout banner = new LinearLayout(this);
        banner.setOrientation(LinearLayout.VERTICAL);
        banner.setPadding(d(12), d(11), d(12), d(11));
        banner.setBackground(bg(Color.rgb(15, 23, 42), 0));
        captureHint = label("点选目标位置（最多3个）", 14, true, Color.WHITE);
        banner.addView(captureHint, childParams(-1, 34));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        banner.addView(row, childParams(-1, 42));
        Button done = mini("完成", Color.rgb(22, 163, 74));
        Button undo = mini("撤销", BLUE);
        Button cancel = mini("取消", Color.rgb(71, 85, 105));
        for (Button button : new Button[] { done, undo, cancel }) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, d(39), 1f);
            p.rightMargin = d(5);
            row.addView(button, p);
        }
        done.setOnClickListener(v -> {
            if (draftPoints.isEmpty()) {
                toast("请先在屏幕上选至少一个位置");
                return;
            }
            points.clear();
            points.addAll(draftPoints);
            TapSettings.savePoints(this, points);
            closeCapture();
            showFloatingPanel();
            updateStatus("已保存 " + points.size() + " 个点，等待开始");
        });
        undo.setOnClickListener(v -> {
            if (!draftPoints.isEmpty()) draftPoints.remove(draftPoints.size() - 1);
            // Remove markers and rebuild them from the retained point list.
            for (int i = captureView.getChildCount() - 1; i >= 0; i--) {
                if (captureView.getChildAt(i) != banner) captureView.removeViewAt(i);
            }
            for (int i = 0; i < draftPoints.size(); i++) {
                Point point = draftPoints.get(i);
                showMarker(point.x, point.y, i + 1);
            }
            updateCaptureHint();
        });
        cancel.setOnClickListener(v -> { closeCapture(); showFloatingPanel(); });

        FrameLayout.LayoutParams bannerParams = new FrameLayout.LayoutParams(-1, d(108), Gravity.TOP);
        captureView.addView(banner, bannerParams);
        WindowManager.LayoutParams full = overlayParams(-1, -1);
        try { wm.addView(captureView, full); }
        catch (RuntimeException ex) {
            closeCapture();
            showFloatingPanel();
            toast("无法进入取点模式");
        }
    }
    private void showMarker(float x, float y, int index) {
        if (captureView == null) return;
        TextView mark = label(String.valueOf(index), 14, true, Color.WHITE);
        mark.setGravity(Gravity.CENTER);
        mark.setBackground(bg(Color.rgb(220, 38, 38), 99));
        FrameLayout.LayoutParams pos = new FrameLayout.LayoutParams(d(32), d(32));
        pos.leftMargin = Math.max(0, Math.round(x) - d(16));
        pos.topMargin = Math.max(0, Math.round(y) - d(16));
        captureView.addView(mark, pos);
        mark.setClickable(false);
    }
    private void updateCaptureHint() {
        if (captureHint != null) captureHint.setText("已选 " + draftPoints.size() + "/3 点 · 完成 / 撤销 / 取消");
    }

    private boolean targetForeground() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        return root != null && root.getPackageName() != null
                && TapSettings.TARGET_PACKAGE.contentEquals(root.getPackageName());
    }
    private boolean sensitivePageVisible(AccessibilityNodeInfo root) {
        if (root == null) return true;
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.offer(root);
        int visited = 0;
        while (!queue.isEmpty() && visited++ < 300) {
            AccessibilityNodeInfo node = queue.poll();
            if (node == null) continue;
            if (!node.isVisibleToUser()) continue;
            CharSequence text = node.getText();
            CharSequence description = node.getContentDescription();
            String combined = (text == null ? "" : text.toString()) + " "
                    + (description == null ? "" : description.toString());
            for (String marker : STOP_MARKERS) {
                if (combined.contains(marker)) return true;
            }
            int count = node.getChildCount();
            for (int i = 0; i < count; i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) queue.offer(child);
            }
        }
        return false;
    }
    private boolean safePoint(Point point) {
        android.util.DisplayMetrics metrics = getResources().getDisplayMetrics();
        if (point.x < 0 || point.y < 0 || point.x >= metrics.widthPixels || point.y >= metrics.heightPixels + d(80)) {
            return false;
        }
        // Do not click through our own touchable controls.
        if (panel != null) {
            int[] location = new int[2];
            panel.getLocationOnScreen(location);
            int right = location[0] + panel.getWidth();
            int bottom = location[1] + panel.getHeight();
            if (point.x >= location[0] && point.x <= right
                    && point.y >= location[1] && point.y <= bottom) return false;
        }
        return true;
    }
    private void armStart() {
        if (running || armed) {
            updateStatus("已启动/预约，请先停止");
            return;
        }
        points.clear();
        points.addAll(TapSettings.loadPoints(this));
        if (points.isEmpty()) {
            updateStatus("请先按‘取点’设置点击位置");
            toast("请先选择点击位置");
            return;
        }
        if (!targetForeground()) {
            updateStatus("当前不是大麦前台，未启动");
            toast("请先打开大麦目标页面，再点悬浮窗‘开始’");
            return;
        }
        for (Point p : points) {
            if (!safePoint(p)) {
                updateStatus("点击坐标无效/被悬浮窗遮挡");
                toast("请拖开悬浮窗或重新取点，避免误点");
                return;
            }
        }
        long delay;
        try {
            delay = TapSettings.delayUntil(TapSettings.scheduledTime(this));
        } catch (IllegalArgumentException e) {
            updateStatus("时间配置错误，未启动");
            toast(e.getMessage());
            return;
        }
        armed = true;
        int token = ++generation;
        if (delay == 0) {
            beginRun(token);
        } else {
            updateStatus(String.format(Locale.CHINA, "已预约：%.1f秒后开始", delay / 1000.0));
            scheduledStart = () -> {
                scheduledStart = null;
                if (armed && token == generation) beginRun(token);
            };
            handler.postDelayed(scheduledStart, delay);
        }
    }
    private void beginRun(int token) {
        if (!armed || token != generation) return;
        if (!targetForeground()) {
            stopActive("到点时未处于大麦，已取消");
            return;
        }
        running = true;
        armed = false;
        tapIndex = 0;
        interval = TapSettings.interval(this);
        int seconds = TapSettings.duration(this);
        maxCount = Math.min(TapSettings.MAX_GESTURES, Math.max(1, (seconds * 1000) / interval));
        finishTime = SystemClock.uptimeMillis() + seconds * 1000L;
        updateStatus("执行中 0/" + maxCount + " · 点‘停止’可取消");
        tick(token);
    }
    private void tick(int token) {
        if (!running || token != generation) return;
        if (SystemClock.uptimeMillis() >= finishTime || tapIndex >= maxCount) {
            stopActive("已达到次数/时长上限，停止");
            return;
        }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || root.getPackageName() == null
                || !TapSettings.TARGET_PACKAGE.contentEquals(root.getPackageName())) {
            stopActive("离开大麦或页面不可识别，停止");
            return;
        }
        if (sensitivePageVisible(root)) {
            stopActive("检测到支付/验证/订单页面，停止");
            return;
        }
        Point p = points.get(tapIndex % points.size());
        if (!safePoint(p)) {
            stopActive("点击位置被遮挡或超出屏幕，停止");
            return;
        }
        Path path = new Path();
        path.moveTo(p.x, p.y);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path, 0, 65);
        GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
        boolean sent;
        try {
            sent = dispatchGesture(gesture, new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription gestureDescription) {
                    if (!running || token != generation) return;
                    tapIndex++;
                    updateStatus("执行中 " + tapIndex + "/" + maxCount + " · 可随时停止");
                    handler.postDelayed(() -> tick(token), Math.max(0, interval - 65));
                }
                @Override public void onCancelled(GestureDescription gestureDescription) {
                    if (running && token == generation) stopActive("手势被系统取消，已停止");
                }
            }, handler);
        } catch (RuntimeException e) {
            sent = false;
        }
        if (!sent) stopActive("点击指令未被系统接受，已停止");
    }
    private void stopActive(String message) {
        ++generation;
        running = false;
        armed = false;
        if (scheduledStart != null) {
            handler.removeCallbacks(scheduledStart);
            scheduledStart = null;
        }
        updateStatus(message);
    }
}
