package com.piaodian.helper;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Point;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/** Local-only settings. Coordinates are stored on-device and are never uploaded. */
public final class TapSettings {
    private static final String PREFS = "tap_settings_v1";
    public static final int MIN_INTERVAL = 500;
    public static final int MAX_INTERVAL = 3000;
    public static final int MAX_DURATION = 30;
    public static final int MAX_GESTURES = 40;
    public static final int MAX_POINTS = 3;
    public static final String TARGET_PACKAGE = "cn.damai";

    private TapSettings() {}

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static int interval(Context c) {
        return clamp(prefs(c).getInt("interval", 900), MIN_INTERVAL, MAX_INTERVAL);
    }
    public static int duration(Context c) {
        return clamp(prefs(c).getInt("duration", 20), 5, MAX_DURATION);
    }
    public static String scheduledTime(Context c) {
        return prefs(c).getString("schedule", "");
    }
    public static void save(Context c, int interval, int duration, String scheduledTime) {
        prefs(c).edit()
                .putInt("interval", clamp(interval, MIN_INTERVAL, MAX_INTERVAL))
                .putInt("duration", clamp(duration, 5, MAX_DURATION))
                .putString("schedule", scheduledTime == null ? "" : scheduledTime.trim())
                .apply();
    }
    public static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }
    public static void savePoints(Context c, List<Point> points) {
        StringBuilder sb = new StringBuilder();
        int n = Math.min(MAX_POINTS, points.size());
        for (int i = 0; i < n; i++) {
            if (i > 0) sb.append(';');
            Point p = points.get(i);
            sb.append(p.x).append(',').append(p.y);
        }
        prefs(c).edit().putString("points", sb.toString()).apply();
    }
    public static List<Point> loadPoints(Context c) {
        ArrayList<Point> result = new ArrayList<>();
        String raw = prefs(c).getString("points", "");
        if (raw == null || raw.isEmpty()) return result;
        for (String item : raw.split(";")) {
            String[] xy = item.split(",");
            if (xy.length != 2) continue;
            try {
                int x = Integer.parseInt(xy[0]);
                int y = Integer.parseInt(xy[1]);
                if (x >= 0 && y >= 0) result.add(new Point(x, y));
                if (result.size() >= MAX_POINTS) break;
            } catch (NumberFormatException ignored) { }
        }
        return result;
    }
    /** Returns 0 if immediate. Strict local-time same-day scheduling only. */
    public static long delayUntil(String value) throws IllegalArgumentException {
        if (value == null || value.trim().isEmpty()) return 0L;
        String time = value.trim();
        if (!time.matches("\\d{2}:\\d{2}:\\d{2}")) {
            throw new IllegalArgumentException("时间格式应为 HH:mm:ss，例如 12:00:00");
        }
        String[] parts = time.split(":");
        int h = Integer.parseInt(parts[0]);
        int m = Integer.parseInt(parts[1]);
        int s = Integer.parseInt(parts[2]);
        if (h > 23 || m > 59 || s > 59) throw new IllegalArgumentException("时间数值超出范围");
        Calendar now = Calendar.getInstance();
        Calendar scheduled = Calendar.getInstance();
        scheduled.set(Calendar.HOUR_OF_DAY, h);
        scheduled.set(Calendar.MINUTE, m);
        scheduled.set(Calendar.SECOND, s);
        scheduled.set(Calendar.MILLISECOND, 0);
        long delay = scheduled.getTimeInMillis() - now.getTimeInMillis();
        if (delay < 0) throw new IllegalArgumentException("这个时间今天已经过去；请修改为今天稍后的时间");
        if (delay > 30L * 60L * 1000L) {
            throw new IllegalArgumentException("仅支持未来30分钟内的定时启动，以免误触");
        }
        return delay;
    }
    public static String describe(Context c) {
        return String.format(Locale.CHINA, "%dms/次 · %d秒 · 最多%d次",
                interval(c), duration(c), MAX_GESTURES);
    }
}
