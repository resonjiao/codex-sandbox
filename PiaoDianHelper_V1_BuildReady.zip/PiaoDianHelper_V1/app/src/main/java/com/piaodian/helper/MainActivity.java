package com.piaodian.helper;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {
    private static final int NAVY = Color.rgb(15, 23, 42);
    private static final int BLUE = Color.rgb(37, 99, 235);
    private static final int PALE = Color.rgb(239, 246, 255);
    private EditText intervalInput, durationInput, scheduleInput;
    private TextView permissionState, pointsState;

    private int d(float dp) { return Math.round(dp * getResources().getDisplayMetrics().density); }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(d(radius));
        return g;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }
    private void pad(View v, int a, int b, int c, int e) {
        v.setPadding(d(a), d(b), d(c), d(e));
    }
    private LinearLayout.LayoutParams lp(int width, int height, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(width < 0 ? width : d(width),
                height < 0 ? height : d(height));
        p.bottomMargin = d(bottom);
        return p;
    }
    private Button button(String title, boolean primary) {
        Button b = new Button(this);
        b.setText(title);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTextColor(primary ? Color.WHITE : NAVY);
        b.setBackground(bg(primary ? BLUE : PALE, 12));
        return b;
    }
    private EditText input(String value, String hint, boolean numbers) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setTextSize(17);
        e.setTextColor(NAVY);
        e.setInputType(numbers ? InputType.TYPE_CLASS_NUMBER : InputType.TYPE_CLASS_TEXT);
        e.setBackground(bg(Color.rgb(248, 250, 252), 9));
        pad(e, 13, 10, 13, 10);
        return e;
    }
    private void section(LinearLayout parent, String title, View field, String explanation) {
        TextView label = text(title, 15, NAVY, true);
        parent.addView(label, lp(-1, -2, 7));
        parent.addView(field, lp(-1, 48, 5));
        TextView details = text(explanation, 12, Color.rgb(100, 116, 139), false);
        parent.addView(details, lp(-1, -2, 18));
    }
    private void notice(LinearLayout parent, String message) {
        TextView v = text(message, 13, Color.rgb(51, 65, 85), false);
        pad(v, 14, 13, 14, 13);
        v.setBackground(bg(PALE, 12));
        parent.addView(v, lp(-1, -2, 15));
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(NAVY);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(248, 250, 252));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        pad(root, 20, 24, 20, 26);
        scroll.addView(root);
        setContentView(scroll);

        TextView brand = text("票点助手", 30, NAVY, true);
        root.addView(brand, lp(-1, -2, 5));
        TextView subtitle = text("V1.0 · 荣耀 WIN RT / 大麦限时点击辅助", 14, Color.rgb(71, 85, 105), false);
        root.addView(subtitle, lp(-1, -2, 17));
        notice(root, "仅对大麦（cn.damai）执行用户选择的点击；屏幕须点亮、保持大麦前台。出现支付、验证码等界面自动停止。没有抢票保证。请遵守平台规则。");

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        pad(card, 17, 18, 17, 5);
        card.setBackground(bg(Color.WHITE, 16));
        root.addView(card, lp(-1, -2, 17));
        TextView heading = text("点击配置", 19, NAVY, true);
        card.addView(heading, lp(-1, -2, 18));

        intervalInput = input(String.valueOf(TapSettings.interval(this)), "900", true);
        section(card, "点击间隔（毫秒）", intervalInput, "允许 500–3000 毫秒；过快不会提高出票概率。");
        durationInput = input(String.valueOf(TapSettings.duration(this)), "20", true);
        section(card, "最长运行时间（秒）", durationInput, "允许 5–30 秒；最多 40 次点击，达到任一上限自动停止。");
        scheduleInput = input(TapSettings.scheduledTime(this), "例如 12:00:00（留空则立即开始）", false);
        section(card, "定时启动（手机本地时间）", scheduleInput, "仅支持当天未来30分钟内；定时可能受省电/系统调度影响。");

        Button save = button("保存以上配置", true);
        card.addView(save, lp(-1, 47, 15));
        save.setOnClickListener(v -> saveSettings());

        TextView actions = text("启动步骤", 19, NAVY, true);
        root.addView(actions, lp(-1, -2, 10));
        permissionState = text("", 14, NAVY, false);
        root.addView(permissionState, lp(-1, -2, 10));
        Button accessibility = button("① 开启无障碍点击权限", false);
        root.addView(accessibility, lp(-1, 49, 10));
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        Button floating = button("② 显示悬浮控制窗", true);
        root.addView(floating, lp(-1, 49, 10));
        floating.setOnClickListener(v -> {
            if (!saveSettings()) return;
            TapAccessibilityService service = TapAccessibilityService.getInstance();
            if (service == null) {
                Toast.makeText(this, "请先开启‘票点助手手动点击服务’无障碍权限", Toast.LENGTH_LONG).show();
                return;
            }
            service.showFloatingPanel();
            Toast.makeText(this, "悬浮窗已显示；打开大麦后使用‘取点’", Toast.LENGTH_LONG).show();
            refreshStates();
        });
        Button damai = button("③ 打开大麦 APP", false);
        root.addView(damai, lp(-1, 49, 13));
        damai.setOnClickListener(v -> {
            Intent launch = getPackageManager().getLaunchIntentForPackage(TapSettings.TARGET_PACKAGE);
            if (launch == null) {
                Toast.makeText(this, "未检测到大麦，请安装后再试，或手动打开", Toast.LENGTH_LONG).show();
                return;
            }
            startActivity(launch);
        });
        pointsState = text("", 14, Color.rgb(71, 85, 105), false);
        root.addView(pointsState, lp(-1, -2, 14));
        notice(root, "使用方法：进入大麦目标页面 → 点击悬浮窗‘取点’ → 点目标按钮所在位置 → 点‘完成’ → 返回大麦页面用悬浮窗‘开始’。悬浮窗可拖动，勿遮住目标位置。点击器不提交订单、不处理验证码、不进行支付。");
    }

    private boolean saveSettings() {
        try {
            int interval = Integer.parseInt(intervalInput.getText().toString().trim());
            int duration = Integer.parseInt(durationInput.getText().toString().trim());
            if (interval < TapSettings.MIN_INTERVAL || interval > TapSettings.MAX_INTERVAL) {
                throw new IllegalArgumentException("点击间隔应为 500–3000 毫秒");
            }
            if (duration < 5 || duration > TapSettings.MAX_DURATION) {
                throw new IllegalArgumentException("最长运行时间应为 5–30 秒");
            }
            String time = scheduleInput.getText().toString().trim();
            if (!time.isEmpty()) TapSettings.delayUntil(time);
            TapSettings.save(this, interval, duration, time);
            Toast.makeText(this, "配置已保存", Toast.LENGTH_SHORT).show();
            return true;
        } catch (NumberFormatException ex) {
            Toast.makeText(this, "请填写有效的数字", Toast.LENGTH_LONG).show();
        } catch (IllegalArgumentException ex) {
            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_LONG).show();
        }
        return false;
    }

    @Override protected void onResume() {
        super.onResume();
        refreshStates();
    }
    private void refreshStates() {
        if (permissionState == null) return;
        boolean enabled = TapAccessibilityService.getInstance() != null;
        permissionState.setText(enabled ? "● 无障碍服务：已连接" : "○ 无障碍服务：未连接");
        if (pointsState != null) {
            int n = TapSettings.loadPoints(this).size();
            pointsState.setText(String.format(Locale.CHINA, "当前已保存 %d 个点击位置（最多 %d 个）", n, TapSettings.MAX_POINTS));
        }
    }
}
