import javax.tools.*;
import com.sun.source.util.JavacTask;
import java.util.*;
import java.nio.file.*;

public class SyntaxCheck {
    public static void main(String[] args) throws Exception {
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();
        StandardJavaFileManager manager = compiler.getStandardFileManager(diagnostics, Locale.ROOT, null);
        ArrayList<java.io.File> sources = new ArrayList<>();
        for (String a : args) sources.add(new java.io.File(a));
        Iterable<? extends JavaFileObject> units = manager.getJavaFileObjectsFromFiles(sources);
        JavacTask task = (JavacTask) compiler.getTask(null, manager, diagnostics,
            Arrays.asList("-proc:none", "-source", "17"), null, units);
        int parsed = 0;
        for (Object ignored : task.parse()) parsed++;
        long errors = diagnostics.getDiagnostics().stream()
            .filter(d -> d.getKind() == Diagnostic.Kind.ERROR)
            .peek(System.err::println).count();
        manager.close();
        System.out.println("Java source syntax checked: " + parsed + "; syntax errors: " + errors);
        if (errors > 0) System.exit(1);
    }
}
