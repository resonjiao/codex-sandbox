package android.content;
public interface SharedPreferences {
    int getInt(String key, int value);
    String getString(String key, String value);
    Editor edit();
    interface Editor {
        Editor putInt(String key, int value);
        Editor putString(String key, String value);
        void apply();
    }
}
