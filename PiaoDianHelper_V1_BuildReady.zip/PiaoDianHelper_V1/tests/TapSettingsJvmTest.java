import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Point;
import com.piaodian.helper.TapSettings;
import java.util.*;

/** JVM logic tests with harmless Android stubs: no device or instrumentation. */
public class TapSettingsJvmTest {
    static class FakePrefs implements SharedPreferences, SharedPreferences.Editor {
        final Map<String,Object> data = new HashMap<>();
        public int getInt(String k, int d) {return data.containsKey(k) ? (Integer)data.get(k):d;}
        public String getString(String k, String d) {return data.containsKey(k) ? (String)data.get(k):d;}
        public Editor edit() {return this;}
        public Editor putInt(String k, int v) {data.put(k,v); return this;}
        public Editor putString(String k, String v) {data.put(k,v); return this;}
        public void apply() {}
    }
    static class FakeContext extends Context {
        final FakePrefs data = new FakePrefs();
        @Override public SharedPreferences getSharedPreferences(String n, int m) {return data;}
    }
    static void check(boolean okay, String message) {
        if (!okay) throw new AssertionError(message);
    }
    static void invalid(String value) {
        boolean failed = false;
        try { TapSettings.delayUntil(value); } catch (IllegalArgumentException e) {failed = true;}
        check(failed, "expected invalid: " + value);
    }
    public static void main(String[] args) {
        FakeContext context = new FakeContext();
        check(TapSettings.interval(context) == 900, "default interval");
        check(TapSettings.duration(context) == 20, "default duration");
        TapSettings.save(context, 10, 1000, "");
        check(TapSettings.interval(context) == TapSettings.MIN_INTERVAL, "interval clamped");
        check(TapSettings.duration(context) == TapSettings.MAX_DURATION, "duration clamped");
        List<Point> points = Arrays.asList(new Point(100,200), new Point(300,400), new Point(500,600), new Point(700,800));
        TapSettings.savePoints(context, points);
        List<Point> got = TapSettings.loadPoints(context);
        check(got.size() == 3 && got.get(2).x == 500, "point count capped and stored");
        check(TapSettings.delayUntil("") == 0, "empty schedule immediate");
        invalid("12:00"); invalid("24:00:00"); invalid("20:61:00"); invalid("08:20:60");
        invalid("nope");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MINUTE, 2);
        String soon = String.format(Locale.ROOT, "%02d:%02d:%02d", cal.get(Calendar.HOUR_OF_DAY),
           cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND));
        check(TapSettings.delayUntil(soon) > 0, "future today schedule");
        System.out.println("TapSettings JVM logic tests: PASS (defaults, clamps, points, schedule)");
    }
}
