"""Static and safe build-independent smoke checks; NOT Android device or APK tests."""
from pathlib import Path
from lxml import etree
import re

ROOT = Path(__file__).resolve().parents[1]
xml_files = list((ROOT / 'app/src/main').rglob('*.xml'))
for p in xml_files:
    etree.parse(str(p))
print(f'XML files well-formed: {len(xml_files)}')

manifest = etree.parse(str(ROOT / 'app/src/main/AndroidManifest.xml'))
xml = manifest.getroot()
ns = '{http://schemas.android.com/apk/res/android}'
permissions = [p.attrib.get(ns + 'name') for p in xml.findall('uses-permission')]
for risky in ['android.permission.INTERNET', 'android.permission.SYSTEM_ALERT_WINDOW',
              'android.permission.READ_SMS', 'android.permission.READ_CONTACTS']:
    assert risky not in permissions, risky
assert manifest.xpath('//*[local-name()="service"]')
assert manifest.xpath('//*[local-name()="activity"]')

accessibility = etree.parse(str(ROOT/'app/src/main/res/xml/accessibility_service_config.xml')).getroot()
assert accessibility.attrib[ns+'canPerformGestures'] == 'true'
assert accessibility.attrib[ns+'canRetrieveWindowContent'] == 'true'

code_dir = ROOT / 'app/src/main/java/com/piaodian/helper'
settings = (code_dir/'TapSettings.java').read_text()
service = (code_dir/'TapAccessibilityService.java').read_text()
activity = (code_dir/'MainActivity.java').read_text()
assert 'cn.damai' in settings
for s in ['MAX_GESTURES = 40', 'MAX_POINTS = 3', 'MAX_DURATION = 30', 'MIN_INTERVAL = 500']:
    assert s in settings, s
for s in ['targetForeground()', 'sensitivePageVisible(root)', 'dispatchGesture(',
          'TYPE_ACCESSIBILITY_OVERLAY', 'stopActive(', 'getRootInActiveWindow()']:
    assert s in service, s
assert 'TYPE_APPLICATION_OVERLAY' not in service
assert 'startActivity(launch)' in activity
assert 'saveSettings()' in activity
assert 'android:exported="true"' in (ROOT/'app/src/main/AndroidManifest.xml').read_text()
print('Core Android declarations, privacy constraints and safety gates: PASS')
print('NOTE: no Android SDK available; APK build and device behavior are NOT verified.')
