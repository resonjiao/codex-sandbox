#!/bin/sh
set -eu
# Required when this source tree contains Chinese filenames and the build host defaults to ASCII.
export LANG=C.UTF-8
export LC_ALL=C.UTF-8
cd "$(dirname "$0")/.."
python tests/smoke_test.py
mkdir -p /tmp/piaodian_testclasses
javac -encoding UTF-8 -d /tmp/piaodian_testclasses tests/SyntaxCheck.java
java -cp /tmp/piaodian_testclasses SyntaxCheck app/src/main/java/com/piaodian/helper/*.java
javac -encoding UTF-8 -d /tmp/piaodian_testclasses \
  tests/jvm_stubs/android/content/*.java \
  tests/jvm_stubs/android/graphics/*.java \
  app/src/main/java/com/piaodian/helper/TapSettings.java tests/TapSettingsJvmTest.java
java -cp /tmp/piaodian_testclasses TapSettingsJvmTest
