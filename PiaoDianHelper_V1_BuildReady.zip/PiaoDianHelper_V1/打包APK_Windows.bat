@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ==========================================
echo 票点助手 V1 - Windows 本地 APK 打包
echo ==========================================
where gradle >nul 2>&1
if errorlevel 1 (
    echo [缺少 Gradle] 未找到可用的 gradle 命令。
    echo 请阅读 APK_云端自动编译_操作说明.txt 在 GitHub Actions 云端编译。
    echo 也可在安装 Android SDK 和 Gradle 8.11.1 的电脑上运行本脚本。
    pause
    exit /b 1
)
if not defined ANDROID_HOME if not defined ANDROID_SDK_ROOT (
    echo [提示] 未检测到 ANDROID_HOME 或 ANDROID_SDK_ROOT。
    echo 若 SDK 安装在默认位置，构建可能仍能自动检测，否则请设置环境变量。
)
gradle --no-daemon :app:assembleDebug
if errorlevel 1 (
    echo [错误] 编译失败，请检查日志、SDK Platform 35 及 Java 17。
    pause
    exit /b 1
)
if not exist "app\build\outputs\apk\debug\app-debug.apk" (
    echo [错误] 构建流程未生成 APK。
    pause
    exit /b 1
)
copy /Y "app\build\outputs\apk\debug\app-debug.apk" "票点助手_V1_调试版.apk" >nul
echo [成功] APK 文件：%cd%\票点助手_V1_调试版.apk
pause
